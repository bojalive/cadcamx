(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["chunks/_next-internal_server_app_icon_route_actions_6c46f2f4.js",23305,(s,_,n)=>{}]);

//# sourceMappingURL=_next-internal_server_app_icon_route_actions_6c46f2f4.js.map