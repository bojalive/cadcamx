globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/3713568cc634a865.js",
      "static/chunks/turbopack-c9a2d38a675fd442.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/3713568cc634a865.js",
      "static/chunks/turbopack-a154c91e0f2317ee.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3b7091f687ab146c.js",
    "static/chunks/e9173429ac19f9e8.js",
    "static/chunks/111c2078ff56494a.js",
    "static/chunks/3e0f93b37bf948e9.js",
    "static/chunks/turbopack-651695f599d90382.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];