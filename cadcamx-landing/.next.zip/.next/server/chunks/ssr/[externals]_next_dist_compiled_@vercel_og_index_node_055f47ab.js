module.exports=[21425,a=>a.a(async(b,c)=>{try{let b=await a.y("next/dist/compiled/@vercel/og/index.node.js");a.n(b),c()}catch(a){c(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_next_dist_compiled_%40vercel_og_index_node_055f47ab.js.map