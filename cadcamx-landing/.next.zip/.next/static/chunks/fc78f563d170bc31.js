__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/3713568cc634a865.js",
  "static/chunks/turbopack-c9a2d38a675fd442.js"
])
